import cis463.util.*;
import cis463.fsm.*;
import java.util.*;

/**
 * a skeleton TokenReader for Pascal tokens --
 * the only tokens returned are ERROR (for alphabetic characters)
 * and EOF
 */
public class TokenReader implements StreamReader<Token> {

    private LineIO lio;              // a StreamReader<Character>
    private Lazy<Character> lzyin;   // a Lazy<Character> based on lio
    private static final char NL = '\n';    // the newline character

    public TokenReader(LineIO lio) {
	this.lio = lio;
	lzyin = new Lazy<Character>(lio);
    }

    // this variable is referenced in each FSMState method
    private Token tok;

    // the FSM states
    private FSMState t_INIT = new FSMState() {
	    public FSMState next() {
		Character ch = lzyin.cur();
		if (ch == null) {
		    // end of file
		    tok.lno = lio.getLineNumber();
		    tok.str.append("*EOF*");
		    tok.val = Token.Val.EOF;
		    return null;
		}
		lzyin.adv();
		if (Character.isLetter(ch)) {
		    tok.lno = lio.getLineNumber();
		    tok.str.append(ch);
		    tok.val = Token.Val.ERROR;
		    return  null;
		}
		// ignore anything else
		return t_INIT; // ... could loop instead ...
	    }
	};
    
    public Token read() {
	tok = new Token();
	FSM.run(t_INIT); // initialize and run the FSM
	return tok;
    }
}
