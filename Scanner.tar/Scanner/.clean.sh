#!/bin/bash

[ -d build/ ] && rm -r build/
[ -d javadoc/ ] && rm -r javadoc/


